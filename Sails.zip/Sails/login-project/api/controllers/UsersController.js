/**
 * UsersController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */
const jwt = require('jsonwebtoken');
module.exports = {
    
    getProfile: (req,res) =>{
        const {userid} = req.tokenInfor;
            Users.findOne({id : userid}).exec((err,user) =>{
                if(err) throw err;
                res.send(JSON.stringify(user));
            }, trace => {console.log(trace)})
        
    },
};

